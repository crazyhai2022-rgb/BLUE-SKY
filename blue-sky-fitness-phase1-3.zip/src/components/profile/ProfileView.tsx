"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  UserRound,
  LogOut,
  ShieldCheck,
  BellRing,
  Ruler,
  Sparkles,
  Watch,
  Pencil,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import type { Profile, FitnessGoalType } from "@/types";

type MinimalDevice = { id: string; device_name: string; status: string };

export function ProfileView({
  email,
  profile,
  goal,
  coachSetupComplete,
  devices,
}: {
  email: string;
  profile: Profile | null;
  goal: { goal_type: FitnessGoalType; target_weight_kg: number | null } | null;
  coachSetupComplete: boolean;
  devices: MinimalDevice[];
}) {
  const router = useRouter();
  const supabase = createClient();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    full_name: profile?.full_name ?? "",
    age: profile?.age ?? "",
    height_cm: profile?.height_cm ?? "",
    weight_kg: profile?.weight_kg ?? "",
    target_weight_kg: profile?.target_weight_kg ?? "",
  });

  async function handleSave() {
    setSaving(true);
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (user) {
      await supabase
        .from("profiles")
        .update({
          full_name: form.full_name || null,
          age: form.age ? Number(form.age) : null,
          height_cm: form.height_cm ? Number(form.height_cm) : null,
          weight_kg: form.weight_kg ? Number(form.weight_kg) : null,
          target_weight_kg: form.target_weight_kg ? Number(form.target_weight_kg) : null,
        })
        .eq("id", user.id);
    }

    setSaving(false);
    setEditing(false);
    router.refresh();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-4 pt-1">
      <header className="flex items-center gap-3">
        <div className="w-16 h-16 rounded-2xl bsf-gradient-primary text-white flex items-center justify-center">
          <UserRound size={28} />
        </div>
        <div className="min-w-0">
          <h1 className="text-lg font-extrabold truncate">{profile?.full_name || "Your Profile"}</h1>
          <p className="text-xs text-slate-500 truncate">{email}</p>
        </div>
      </header>

      <Card>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-semibold">Personal Details</p>
          <button onClick={() => setEditing((v) => !v)} className="text-bsf-blue">
            <Pencil size={15} />
          </button>
        </div>

        {editing ? (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Full Name" full>
              <input
                value={form.full_name}
                onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))}
                className="bsf-input"
              />
            </Field>
            <Field label="Age">
              <input
                type="number"
                value={form.age}
                onChange={(e) => setForm((f) => ({ ...f, age: e.target.value }))}
                className="bsf-input"
              />
            </Field>
            <Field label="Height (cm)">
              <input
                type="number"
                value={form.height_cm}
                onChange={(e) => setForm((f) => ({ ...f, height_cm: e.target.value }))}
                className="bsf-input"
              />
            </Field>
            <Field label="Weight (kg)">
              <input
                type="number"
                value={form.weight_kg}
                onChange={(e) => setForm((f) => ({ ...f, weight_kg: e.target.value }))}
                className="bsf-input"
              />
            </Field>
            <Field label="Target Weight (kg)">
              <input
                type="number"
                value={form.target_weight_kg}
                onChange={(e) => setForm((f) => ({ ...f, target_weight_kg: e.target.value }))}
                className="bsf-input"
              />
            </Field>
            <Button size="sm" disabled={saving} onClick={handleSave} className="col-span-2 mt-1">
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-y-2 text-sm">
            <Stat label="Age" value={profile?.age ? `${profile.age}` : "—"} />
            <Stat label="Height" value={profile?.height_cm ? `${profile.height_cm} cm` : "—"} />
            <Stat label="Weight" value={profile?.weight_kg ? `${profile.weight_kg} kg` : "—"} />
            <Stat label="Target Weight" value={profile?.target_weight_kg ? `${profile.target_weight_kg} kg` : "—"} />
          </div>
        )}
      </Card>

      <Card className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-bsf-blue" />
          <div>
            <p className="text-sm font-semibold">AI Coach</p>
            <p className="text-xs text-slate-500">{goal ? goal.goal_type.replace(/_/g, " ") : "No goal set"}</p>
          </div>
        </div>
        <Badge tone={coachSetupComplete ? "success" : "warning"}>
          {coachSetupComplete ? "Set Up" : "Not Set Up"}
        </Badge>
      </Card>

      <Card>
        <div className="flex items-center gap-2 mb-2">
          <Watch size={16} className="text-bsf-blue" />
          <p className="text-sm font-semibold">Connected Devices</p>
        </div>
        {devices.length === 0 ? (
          <p className="text-xs text-slate-500">No devices connected yet.</p>
        ) : (
          <ul className="flex flex-col gap-1.5">
            {devices.map((d) => (
              <li key={d.id} className="flex items-center justify-between text-sm">
                <span>{d.device_name}</span>
                <Badge tone={d.status === "connected" ? "success" : "neutral"}>{d.status}</Badge>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card className="flex flex-col divide-y divide-bsf-border">
        <SettingsRow icon={<ShieldCheck size={16} />} label="Privacy &amp; Data Permissions" />
        <SettingsRow icon={<BellRing size={16} />} label="Notification Settings" />
        <SettingsRow icon={<Ruler size={16} />} label={`Units: ${profile?.unit_weight ?? "kg"} · ${profile?.unit_distance ?? "km"} · °${profile?.unit_temperature ?? "C"}`} />
      </Card>

      <Button variant="outline" onClick={handleLogout} className="text-red-500">
        <LogOut size={16} /> Log Out
      </Button>

      <style jsx global>{`
        .bsf-input {
          border: 1px solid var(--bsf-border);
          background: transparent;
          border-radius: 0.65rem;
          padding: 0.5rem 0.65rem;
          font-size: 0.85rem;
          width: 100%;
        }
      `}</style>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={`flex flex-col gap-1 ${full ? "col-span-2" : ""}`}>
      <span className="text-[11px] font-semibold text-slate-500">{label}</span>
      {children}
    </label>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[11px] text-slate-500">{label}</p>
      <p className="font-semibold">{value}</p>
    </div>
  );
}

function SettingsRow({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <button className="flex items-center gap-3 py-3 text-sm text-left">
      <span className="text-bsf-blue">{icon}</span>
      {label}
    </button>
  );
}
