import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

type BadgeTone = "sky" | "success" | "warning" | "danger" | "demo" | "neutral";

const TONE_CLASSES: Record<BadgeTone, string> = {
  sky: "bg-sky-100 text-sky-700 dark:bg-sky-400/15 dark:text-sky-300",
  success: "bg-emerald-100 text-emerald-700 dark:bg-emerald-400/15 dark:text-emerald-300",
  warning: "bg-amber-100 text-amber-700 dark:bg-amber-400/15 dark:text-amber-300",
  danger: "bg-red-100 text-red-700 dark:bg-red-400/15 dark:text-red-300",
  demo: "bg-purple-100 text-purple-700 dark:bg-purple-400/15 dark:text-purple-300",
  neutral: "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-300",
};

export function Badge({
  tone = "neutral",
  className,
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: BadgeTone }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold",
        TONE_CLASSES[tone],
        className
      )}
      {...props}
    />
  );
}

export function DemoBadge({ className }: { className?: string }) {
  return (
    <Badge tone="demo" className={className}>
      ● DEMO DATA
    </Badge>
  );
}
