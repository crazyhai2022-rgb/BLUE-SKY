import { clampPercent } from "@/lib/utils";

export function ProgressRing({
  percent,
  size = 84,
  strokeWidth = 9,
  color = "var(--bsf-sky)",
  trackColor = "var(--bsf-surface-muted)",
  label,
  sublabel,
}: {
  percent: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  sublabel?: string;
}) {
  const p = clampPercent(percent);
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (p / 100) * circumference;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke={trackColor} strokeWidth={strokeWidth} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center text-center">
        <span className="text-sm font-bold leading-none">{label ?? `${p}%`}</span>
        {sublabel && <span className="text-[10px] text-slate-500 mt-1">{sublabel}</span>}
      </div>
    </div>
  );
}

export function ProgressBar({
  percent,
  color = "var(--bsf-sky)",
  trackColor,
  className,
}: {
  percent: number;
  color?: string;
  trackColor?: string;
  className?: string;
}) {
  const p = clampPercent(percent);
  return (
    <div
      className={`h-2.5 w-full rounded-full bg-bsf-surface-muted overflow-hidden ${className ?? ""}`}
      style={trackColor ? { background: trackColor } : undefined}
    >
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${p}%`, background: color }}
      />
    </div>
  );
}
