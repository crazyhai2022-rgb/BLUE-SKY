import type { ReactNode } from "react";
import { Card } from "./Card";
import { Badge } from "./Badge";

export function ComingSoonPage({
  icon,
  title,
  tagline,
  description,
  bullets,
}: {
  icon: ReactNode;
  title: string;
  tagline: string;
  description: string;
  bullets: string[];
}) {
  return (
    <div className="flex flex-col gap-4 pt-1">
      <header>
        <div className="w-12 h-12 rounded-2xl bsf-gradient-primary text-white flex items-center justify-center mb-3">
          {icon}
        </div>
        <h1 className="text-xl font-extrabold">{title}</h1>
        <p className="text-sm text-slate-500 mt-1">{tagline}</p>
      </header>

      <Card>
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-semibold">What&apos;s being built next</p>
          <Badge tone="sky">In Progress</Badge>
        </div>
        <p className="text-sm text-slate-500 leading-relaxed mb-3">{description}</p>
        <ul className="flex flex-col gap-2">
          {bullets.map((b) => (
            <li key={b} className="flex items-start gap-2 text-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-bsf-blue mt-2 shrink-0" />
              {b}
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
