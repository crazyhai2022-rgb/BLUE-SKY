import type { ReactNode } from "react";
import { Card } from "./Card";

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <Card className="flex flex-col items-center text-center gap-3 py-8">
      {icon && (
        <div className="w-14 h-14 rounded-2xl bg-bsf-surface-muted flex items-center justify-center text-bsf-blue">
          {icon}
        </div>
      )}
      <div>
        <p className="font-semibold">{title}</p>
        {description && <p className="text-sm text-slate-500 mt-1 max-w-xs">{description}</p>}
      </div>
      {action}
    </Card>
  );
}
