"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { NAV_ITEMS } from "./nav-items";

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex md:flex-col md:w-64 shrink-0 border-r border-bsf-border bg-bsf-surface min-h-dvh sticky top-0 py-6 px-4">
      <div className="flex items-center gap-2 px-2 mb-8">
        <div className="w-9 h-9 rounded-xl bsf-gradient-primary flex items-center justify-center text-white font-bold text-sm">
          BS
        </div>
        <div>
          <p className="font-bold leading-tight">Blue Sky Fitness</p>
          <p className="text-[11px] text-slate-500 leading-tight">Your AI Coach</p>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname?.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition",
                active
                  ? "bg-sky-50 text-bsf-blue dark:bg-white/10"
                  : "text-slate-500 hover:bg-black/5 dark:hover:bg-white/5"
              )}
            >
              <Icon size={19} strokeWidth={active ? 2.5 : 2} />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto px-2 text-[11px] text-slate-400">
        &quot;Connect. Track. Understand. Improve.&quot;
      </div>
    </aside>
  );
}
