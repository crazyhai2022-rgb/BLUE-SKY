import type { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { BottomNav } from "./BottomNav";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh bsf-app-bg">
      <Sidebar />
      <div className="flex-1 min-w-0">
        <main className="max-w-3xl mx-auto px-4 pt-[calc(env(safe-area-inset-top,0px)+1rem)] pb-28 md:pb-10">
          {children}
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
