import { Home, Sparkles, Bluetooth, UserRound } from "lucide-react";

export const NAV_ITEMS = [
  { href: "/home", label: "Home", icon: Home },
  { href: "/ai-coach", label: "AI Coach", icon: Sparkles },
  { href: "/connectivity", label: "Connectivity", icon: Bluetooth },
  { href: "/profile", label: "Profile", icon: UserRound },
] as const;
