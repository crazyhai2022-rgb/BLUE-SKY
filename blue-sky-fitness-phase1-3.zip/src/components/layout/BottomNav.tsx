"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { NAV_ITEMS } from "./nav-items";

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bsf-glass border-t border-bsf-border"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      <div className="grid grid-cols-4">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname?.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className="flex flex-col items-center justify-center gap-1 py-2.5 min-h-[56px] touch-manipulation"
            >
              <Icon
                size={22}
                strokeWidth={active ? 2.5 : 2}
                className={cn(active ? "text-bsf-blue" : "text-slate-400")}
              />
              <span
                className={cn(
                  "text-[11px] font-medium",
                  active ? "text-bsf-blue" : "text-slate-400"
                )}
              >
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
