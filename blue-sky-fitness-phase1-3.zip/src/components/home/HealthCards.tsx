"use client";

import { useState } from "react";
import {
  Footprints,
  Moon,
  HeartPulse,
  Droplets,
  Thermometer,
  Scale,
  Pencil,
} from "lucide-react";
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card } from "@/components/ui/Card";
import { ProgressRing, ProgressBar } from "@/components/ui/ProgressRing";
import { DemoBadge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { clampPercent } from "@/lib/utils";
import type {
  ActivitySummary,
  SleepSummary,
  HeartRateSummary,
  Spo2Summary,
  TemperatureSummary,
  WeightSummary,
} from "@/types";

function CardHeader({
  icon,
  title,
  isDemo,
}: {
  icon: React.ReactNode;
  title: string;
  isDemo?: boolean;
}) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-2 text-slate-500 text-xs font-semibold uppercase tracking-wide">
        {icon}
        {title}
      </div>
      {isDemo && <DemoBadge />}
    </div>
  );
}

// ---------------- STEPS ----------------
export function StepsCard({
  activity,
  stepGoal,
  onSaveGoal,
}: {
  activity: ActivitySummary;
  stepGoal: number;
  onSaveGoal?: (goal: number) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [goalInput, setGoalInput] = useState(String(stepGoal));
  const pct = clampPercent((activity.steps / stepGoal) * 100);

  return (
    <Card>
      <CardHeader icon={<Footprints size={15} />} title="Activity / Steps" isDemo={activity.is_demo} />
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-2xl font-extrabold">{activity.steps.toLocaleString("en-IN")}</p>
          <p className="text-xs text-slate-500">
            Goal: {stepGoal.toLocaleString("en-IN")} · {activity.distance_km} km
          </p>
        </div>
        <ProgressRing percent={pct} color="var(--bsf-sky)" size={64} strokeWidth={7} />
      </div>
      <ProgressBar percent={pct} className="mt-3" />

      {editing ? (
        <div className="mt-3 flex items-center gap-2">
          <input
            type="number"
            value={goalInput}
            onChange={(e) => setGoalInput(e.target.value)}
            className="w-28 rounded-lg border border-bsf-border bg-transparent px-2 py-1.5 text-sm"
          />
          <Button
            size="sm"
            onClick={() => {
              onSaveGoal?.(Number(goalInput) || stepGoal);
              setEditing(false);
            }}
          >
            Save Goal
          </Button>
        </div>
      ) : (
        <button
          onClick={() => setEditing(true)}
          className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-bsf-blue"
        >
          <Pencil size={12} /> Edit step goal
        </button>
      )}
    </Card>
  );
}

// ---------------- SLEEP ----------------
export function SleepCard({ sleep }: { sleep: SleepSummary }) {
  const totalH = sleep.total_minutes ? (sleep.total_minutes / 60).toFixed(1) : null;
  const pct = sleep.total_minutes ? clampPercent((sleep.total_minutes / 60 / sleep.goal_hours) * 100) : 0;

  return (
    <Card>
      <CardHeader icon={<Moon size={15} />} title="Sleep" isDemo={sleep.is_demo} />
      {sleep.total_minutes ? (
        <>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-2xl font-extrabold">
                {Math.floor(sleep.total_minutes / 60)}h {sleep.total_minutes % 60}m
              </p>
              <p className="text-xs text-slate-500">
                Goal: {sleep.goal_hours}h · {sleep.sleep_start}–{sleep.sleep_end}
              </p>
            </div>
            <ProgressRing percent={pct} color="#818cf8" size={64} strokeWidth={7} label={`${totalH}h`} />
          </div>
          <div className="grid grid-cols-3 gap-2 mt-3 text-center">
            <SleepStage label="Deep" minutes={sleep.deep_minutes} color="#4338ca" />
            <SleepStage label="REM" minutes={sleep.rem_minutes} color="#818cf8" />
            <SleepStage label="Light" minutes={sleep.light_minutes} color="#c7d2fe" />
          </div>
        </>
      ) : (
        <p className="text-sm text-slate-500">No sleep data available yet.</p>
      )}
    </Card>
  );
}

function SleepStage({ label, minutes, color }: { label: string; minutes: number | null; color: string }) {
  return (
    <div className="rounded-xl bg-bsf-surface-muted py-2">
      <div className="w-2 h-2 rounded-full mx-auto mb-1" style={{ background: color }} />
      <p className="text-xs font-bold">{minutes !== null ? `${minutes}m` : "—"}</p>
      <p className="text-[10px] text-slate-500">{label}</p>
    </div>
  );
}

// ---------------- HEART RATE ----------------
export function HeartRateCard({ hr }: { hr: HeartRateSummary }) {
  return (
    <Card>
      <CardHeader icon={<HeartPulse size={15} />} title="Heart Rate" isDemo={hr.is_demo} />
      {hr.current !== null ? (
        <>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-2xl font-extrabold">
                {hr.current} <span className="text-sm font-medium text-slate-500">BPM</span>
              </p>
              <p className="text-xs text-slate-500">Current heart rate</p>
            </div>
            <div className="flex gap-3 text-right">
              <MiniStat label="Resting" value={hr.resting} />
              <MiniStat label="Avg" value={hr.average} />
              <MiniStat label="Max" value={hr.max} />
            </div>
          </div>
          {hr.trend.length > 0 && (
            <div className="h-20 -mx-2 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={hr.trend}>
                  <defs>
                    <linearGradient id="hrFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" hide />
                  <YAxis hide domain={["dataMin - 10", "dataMax + 10"]} />
                  <Tooltip
                    contentStyle={{ fontSize: 12, borderRadius: 10, border: "none" }}
                    labelFormatter={(l) => `Time ${l}`}
                  />
                  <Area type="monotone" dataKey="bpm" stroke="#ef4444" fill="url(#hrFill)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </>
      ) : (
        <p className="text-sm text-slate-500">No heart rate data available yet.</p>
      )}
    </Card>
  );
}

function MiniStat({ label, value }: { label: string; value: number | null }) {
  return (
    <div>
      <p className="text-sm font-bold">{value ?? "—"}</p>
      <p className="text-[10px] text-slate-500">{label}</p>
    </div>
  );
}

// ---------------- SPO2 ----------------
export function Spo2Card({ spo2 }: { spo2: Spo2Summary }) {
  return (
    <Card>
      <CardHeader icon={<Droplets size={15} />} title="Blood Oxygen (SpO₂)" isDemo={spo2.is_demo} />
      {spo2.current !== null ? (
        <>
          <p className="text-2xl font-extrabold">{spo2.current}%</p>
          <p className="text-xs text-slate-500 mb-2">Today&apos;s SpO₂</p>
          {spo2.trend.length > 0 && (
            <div className="h-16 -mx-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={spo2.trend}>
                  <defs>
                    <linearGradient id="spo2Fill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" hide />
                  <YAxis hide domain={[90, 100]} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 10, border: "none" }} />
                  <Area type="monotone" dataKey="value" stroke="#0ea5e9" fill="url(#spo2Fill)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </>
      ) : (
        <p className="text-sm text-slate-500">
          No SpO₂ reading available. Only shown when your device provides a valid measurement.
        </p>
      )}
    </Card>
  );
}

// ---------------- TEMPERATURE ----------------
export function TemperatureCard({ temp }: { temp: TemperatureSummary }) {
  const sourceLabel =
    temp.source === "skin" ? "Skin temperature" : temp.source === "wrist" ? "Wrist temperature" : "Estimated";

  return (
    <Card>
      <CardHeader icon={<Thermometer size={15} />} title="Body Temperature" isDemo={temp.is_demo} />
      {temp.current_c !== null ? (
        <>
          <p className="text-2xl font-extrabold">{temp.current_c}°C</p>
          <p className="text-xs text-slate-500">{sourceLabel} — not a core body temperature reading</p>
        </>
      ) : (
        <p className="text-sm text-slate-500">No temperature data available from your connected source.</p>
      )}
    </Card>
  );
}

// ---------------- WEIGHT ----------------
export function WeightCard({ weight, onLogWeight }: { weight: WeightSummary; onLogWeight?: (kg: number) => void }) {
  const [editing, setEditing] = useState(false);
  const [input, setInput] = useState(weight.current_kg ? String(weight.current_kg) : "");

  return (
    <Card>
      <CardHeader icon={<Scale size={15} />} title="Weight" isDemo={weight.is_demo} />
      {weight.current_kg !== null ? (
        <>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-extrabold">{weight.current_kg} kg</p>
              <p className="text-xs text-slate-500">
                Goal: {weight.goal_kg ?? "—"} kg
                {weight.weekly_change_kg !== null && (
                  <>
                    {" "}
                    · {weight.weekly_change_kg > 0 ? "+" : ""}
                    {weight.weekly_change_kg} kg / week
                  </>
                )}
              </p>
            </div>
            {weight.goal_kg !== null && (
              <div className="text-xs font-semibold text-bsf-blue text-right">
                {weight.current_kg} → {weight.goal_kg} kg
              </div>
            )}
          </div>
        </>
      ) : (
        <p className="text-sm text-slate-500 mb-2">Add your current weight to begin tracking.</p>
      )}

      {editing ? (
        <div className="mt-3 flex items-center gap-2">
          <input
            type="number"
            step="0.1"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-24 rounded-lg border border-bsf-border bg-transparent px-2 py-1.5 text-sm"
            placeholder="kg"
          />
          <Button
            size="sm"
            onClick={() => {
              const v = Number(input);
              if (v > 0) onLogWeight?.(v);
              setEditing(false);
            }}
          >
            Save
          </Button>
        </div>
      ) : (
        <button onClick={() => setEditing(true)} className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-bsf-blue">
          <Pencil size={12} /> Log weight manually
        </button>
      )}
    </Card>
  );
}
