import Link from "next/link";
import { Watch, BatteryMedium, BatteryWarning } from "lucide-react";
import { GlassCard } from "@/components/ui/Card";
import { DemoBadge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import type { ConnectedDevice } from "@/types";

export function DeviceStatusBar({ device }: { device: ConnectedDevice | null }) {
  if (!device) {
    return (
      <GlassCard className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-bsf-surface-muted flex items-center justify-center">
            <Watch size={18} className="text-slate-400" />
          </div>
          <div>
            <p className="text-sm font-semibold">No device connected</p>
            <p className="text-xs text-slate-500">Connect a wearable to start syncing</p>
          </div>
        </div>
        <Link href="/connectivity">
          <Button size="sm">Connect</Button>
        </Link>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-10 h-10 rounded-xl bsf-gradient-primary flex items-center justify-center text-white shrink-0">
          <Watch size={18} />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold truncate">{device.device_name}</p>
            {device.is_demo && <DemoBadge />}
          </div>
          <div className="flex items-center gap-1 text-xs text-emerald-600 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 bsf-live-dot" />
            {device.status === "connected" ? "Connected" : device.status.replace("_", " ")}
          </div>
        </div>
      </div>
      <div className="text-right shrink-0">
        {device.battery_available && device.battery_level !== null ? (
          <div className="flex items-center gap-1 text-sm font-semibold">
            <BatteryMedium size={16} className="text-bsf-blue" />
            {device.battery_level}%
          </div>
        ) : (
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <BatteryWarning size={14} />
            Not available
          </div>
        )}
      </div>
    </GlassCard>
  );
}
