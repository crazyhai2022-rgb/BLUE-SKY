"use client";

import Link from "next/link";
import { Sparkles, Bell, ChevronRight } from "lucide-react";
import { greeting } from "@/lib/utils";
import { useDemoMode } from "@/lib/hooks/useDemoMode";
import { getDemoDashboard } from "@/lib/demo-data";
import { EMPTY_DASHBOARD } from "@/lib/demo-data";
import { buildDailySummary, checkHeartRateAnomaly } from "@/lib/ai/rule-based-summary";
import { DeviceStatusBar } from "./DeviceStatusBar";
import {
  StepsCard,
  SleepCard,
  HeartRateCard,
  Spo2Card,
  TemperatureCard,
  WeightCard,
} from "./HealthCards";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import type { ConnectedDevice } from "@/types";

export function HomeDashboard({
  userName,
  stepGoal,
  sleepGoalHours,
  realDevices,
}: {
  userName: string;
  stepGoal: number;
  sleepGoalHours: number;
  realDevices: ConnectedDevice[];
}) {
  const { enabled: demoMode, ready, toggle } = useDemoMode();

  const primaryRealDevice = realDevices.find((d) => d.is_primary) ?? realDevices[0] ?? null;

  const data = demoMode
    ? { ...getDemoDashboard(), activity: { ...getDemoDashboard().activity, step_goal: stepGoal }, sleep: { ...getDemoDashboard().sleep, goal_hours: sleepGoalHours } }
    : { ...EMPTY_DASHBOARD, device: primaryRealDevice, activity: { ...EMPTY_DASHBOARD.activity, step_goal: stepGoal }, sleep: { ...EMPTY_DASHBOARD.sleep, goal_hours: sleepGoalHours } };

  const summary = buildDailySummary(data);
  const anomaly = checkHeartRateAnomaly(data);

  if (!ready) return null;

  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-center justify-between pt-1">
        <div>
          <p className="text-xs font-bold tracking-widest text-bsf-blue">BLUE SKY FITNESS</p>
          <h1 className="text-xl font-extrabold mt-0.5">
            {greeting()}, {userName}
          </h1>
          <p className="text-sm text-slate-500">Today&apos;s Health Overview</p>
        </div>
        <Link
          href="/notifications"
          className="w-10 h-10 rounded-full bg-bsf-surface border border-bsf-border flex items-center justify-center shrink-0"
        >
          <Bell size={18} />
        </Link>
      </header>

      <DeviceStatusBar device={data.device} />

      <div className="flex items-center justify-between bsf-glass rounded-xl px-3 py-2">
        <span className="text-xs font-semibold text-slate-500">Demo Mode</span>
        <button
          onClick={() => toggle(!demoMode)}
          className={`relative w-11 h-6 rounded-full transition ${demoMode ? "bg-bsf-blue" : "bg-slate-300 dark:bg-white/15"}`}
        >
          <span
            className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
              demoMode ? "translate-x-5" : ""
            }`}
          />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <StepsCard activity={data.activity} stepGoal={stepGoal} />
        <SleepCard sleep={data.sleep} />
        <HeartRateCard hr={data.heartRate} />
        <Spo2Card spo2={data.spo2} />
        <TemperatureCard temp={data.temperature} />
        <WeightCard weight={data.weight} />
      </div>

      <Link
        href="/home/metrics"
        className="flex items-center justify-center gap-1 text-sm font-semibold text-bsf-blue py-2"
      >
        View More Metrics <ChevronRight size={16} />
      </Link>

      <Card className="bsf-gradient-primary text-white">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles size={16} />
          <p className="text-xs font-bold uppercase tracking-wide">AI Daily Summary</p>
        </div>
        <p className="text-sm leading-relaxed">{summary}</p>
        {anomaly && (
          <p className="text-xs bg-white/15 rounded-lg px-3 py-2 mt-3 leading-relaxed">{anomaly}</p>
        )}
      </Card>

      <Link href="/ai-coach">
        <Button variant="secondary" className="w-full">
          Ask Your AI Coach
        </Button>
      </Link>
    </div>
  );
}
