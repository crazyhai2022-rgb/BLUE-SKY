"use client";

import { useEffect, useState } from "react";

const KEY = "bsf_demo_mode";

/**
 * Demo Mode is a purely client-side, per-browser preference (never mixed
 * into real Supabase health tables). Defaults to ON so the product can be
 * demonstrated instantly without a physical wearable — flip it off once a
 * real device is connected via the Connectivity page.
 */
export function useDemoMode() {
  const [enabled, setEnabled] = useState<boolean | null>(null);

  useEffect(() => {
    // Reads a per-browser preference from localStorage on mount — this is a
    // one-time sync from an external system (not derived from React state),
    // so it's safe outside the "don't setState in effects" guidance.
    const stored = window.localStorage.getItem(KEY);
    // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time read of a per-browser preference on mount, not derived from React state
    setEnabled(stored === null ? true : stored === "true");
  }, []);

  function toggle(next: boolean) {
    setEnabled(next);
    window.localStorage.setItem(KEY, String(next));
  }

  return { enabled: enabled ?? true, ready: enabled !== null, toggle };
}
