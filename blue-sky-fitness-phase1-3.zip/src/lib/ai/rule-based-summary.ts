import type { HomeDashboardData } from "@/types";

/**
 * Rule-based fallback summary (no AI call). Used instantly on the client so
 * the Home page never waits on the network, and as a safe fallback if the
 * `/api/ai/*` backend is unavailable. Only ever describes data that is
 * actually present — never invents a measurement.
 */
export function buildDailySummary(data: HomeDashboardData): string {
  const parts: string[] = [];

  const stepPct = Math.round((data.activity.steps / data.activity.step_goal) * 100);
  if (data.activity.steps > 0) {
    parts.push(`You've completed ${stepPct}% of your step goal today (${data.activity.steps.toLocaleString("en-IN")} steps).`);
  } else {
    parts.push("No step data yet today.");
  }

  if (data.sleep.total_minutes) {
    const hrs = data.sleep.total_minutes / 60;
    const diff = Math.round((hrs - data.sleep.goal_hours) * 60);
    if (diff < -10) {
      parts.push(`Your sleep last night was ${Math.abs(diff)} minutes below your ${data.sleep.goal_hours}h target.`);
    } else if (diff > 10) {
      parts.push(`You slept ${diff} minutes more than your ${data.sleep.goal_hours}h target — nice recovery night.`);
    } else {
      parts.push("Your sleep last night was close to your target.");
    }
  }

  if (data.heartRate.resting) {
    parts.push(`Resting heart rate is ${data.heartRate.resting} BPM, within a typical range for you.`);
  }

  if (data.activity.active_minutes > 0) {
    const level =
      data.activity.active_minutes < 20 ? "light" : data.activity.active_minutes < 45 ? "moderate" : "high";
    parts.push(`Your activity level so far is ${level}.`);
  }

  if (parts.length === 0) {
    return "Connect a device or log data manually to get your first AI daily summary.";
  }

  return parts.join(" ");
}

/**
 * Very light anomaly check — flags an unusually elevated resting HR without
 * ever diagnosing a condition. Kept intentionally conservative.
 */
export function checkHeartRateAnomaly(data: HomeDashboardData): string | null {
  if (data.heartRate.resting && data.heartRate.resting > 100) {
    return "Your recent heart-rate pattern is outside your usual range. Consider reducing workout intensity and, if this persists or you feel unwell, consult a qualified healthcare professional.";
  }
  return null;
}
