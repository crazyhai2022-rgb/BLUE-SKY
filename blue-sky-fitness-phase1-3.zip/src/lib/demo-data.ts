import type { HomeDashboardData, ConnectedDevice } from "@/types";

/**
 * DEMO MODE data generator.
 *
 * This produces realistic-looking, clearly-labelled synthetic data so the
 * product can be demonstrated without a physical wearable. It must never be
 * mixed with real device/user data — every value it returns carries
 * `is_demo: true` so the UI can render a visible "DEMO DATA" badge.
 */

function seededRandom(seed: number) {
  let value = seed;
  return () => {
    value = (value * 9301 + 49297) % 233280;
    return value / 233280;
  };
}

export function getDemoDevice(): ConnectedDevice {
  return {
    id: "demo-watch",
    user_id: "demo",
    device_name: "Demo Watch",
    device_type: "demo",
    connection_method: "demo",
    external_id: null,
    is_primary: true,
    status: "connected",
    battery_level: 82,
    battery_available: true,
    is_demo: true,
    last_synced_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
  };
}

export function getDemoDashboard(): HomeDashboardData {
  const rand = seededRandom(new Date().getDate());
  const hrTrend = Array.from({ length: 12 }, (_, i) => ({
    time: `${(i * 2).toString().padStart(2, "0")}:00`,
    bpm: Math.round(65 + rand() * 25 + (i > 6 && i < 9 ? 30 : 0)),
  }));
  const spo2Trend = Array.from({ length: 8 }, (_, i) => ({
    time: `${(i * 3).toString().padStart(2, "0")}:00`,
    value: Math.round(95 + rand() * 3),
  }));

  return {
    device: getDemoDevice(),
    heartRate: {
      current: 72,
      resting: 68,
      average: 74,
      min: 58,
      max: 142,
      is_demo: true,
      trend: hrTrend,
    },
    sleep: {
      total_minutes: 452,
      deep_minutes: 98,
      rem_minutes: 112,
      light_minutes: 210,
      awake_minutes: 32,
      sleep_start: "23:12",
      sleep_end: "06:44",
      goal_hours: 8,
      is_demo: true,
    },
    activity: {
      steps: 6842,
      step_goal: 10000,
      distance_km: 4.9,
      calories_burned: 1840,
      active_minutes: 46,
      floors_climbed: 6,
      is_demo: true,
    },
    spo2: {
      current: 97,
      trend: spo2Trend,
      is_demo: true,
    },
    temperature: {
      current_c: 36.7,
      source: "wrist",
      is_demo: true,
    },
    weight: {
      current_kg: 72.4,
      previous_kg: 73.1,
      goal_kg: 68,
      weekly_change_kg: -0.4,
      monthly_change_kg: -1.6,
      is_demo: true,
    },
  };
}

export const EMPTY_DASHBOARD: HomeDashboardData = {
  device: null,
  heartRate: { current: null, resting: null, average: null, min: null, max: null, is_demo: false, trend: [] },
  sleep: {
    total_minutes: null,
    deep_minutes: null,
    rem_minutes: null,
    light_minutes: null,
    awake_minutes: null,
    sleep_start: null,
    sleep_end: null,
    goal_hours: 8,
    is_demo: false,
  },
  activity: { steps: 0, step_goal: 10000, distance_km: 0, calories_burned: 0, active_minutes: 0, floors_climbed: null, is_demo: false },
  spo2: { current: null, trend: [], is_demo: false },
  temperature: { current_c: null, source: null, is_demo: false },
  weight: { current_kg: null, previous_kg: null, goal_kg: null, weekly_change_kg: null, monthly_change_kg: null, is_demo: false },
};
