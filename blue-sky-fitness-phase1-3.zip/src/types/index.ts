// ========================================================
// BLUE SKY FITNESS — SHARED TYPES
// ========================================================

export type SupportLevel = "supported" | "partially_supported" | "unsupported";

export type ConnectionMethod =
  | "bluetooth"
  | "wifi_cloud"
  | "health_platform"
  | "manufacturer"
  | "demo";

export type DeviceStatus =
  | "connected"
  | "disconnected"
  | "reconnecting"
  | "permission_required";

export type MetricType =
  | "heart_rate"
  | "steps"
  | "sleep"
  | "spo2"
  | "temperature"
  | "weight"
  | "calories"
  | "distance"
  | "battery";

export interface ConnectedDevice {
  id: string;
  user_id: string;
  device_name: string;
  device_type:
    | "smart_watch"
    | "fitness_band"
    | "heart_rate_sensor"
    | "smart_scale"
    | "other_ble"
    | "demo";
  connection_method: ConnectionMethod;
  external_id: string | null;
  is_primary: boolean;
  status: DeviceStatus;
  battery_level: number | null;
  battery_available: boolean;
  is_demo: boolean;
  last_synced_at: string | null;
  created_at: string;
}

export interface DeviceCapability {
  metric_type: MetricType;
  support_level: SupportLevel;
}

export type FitnessGoalType =
  | "weight_loss"
  | "weight_gain"
  | "muscle_gain"
  | "improve_fitness"
  | "improve_endurance"
  | "improve_strength"
  | "maintain_weight"
  | "improve_wellness";

export type ActivityLevel =
  | "sedentary"
  | "lightly_active"
  | "moderately_active"
  | "very_active"
  | "extremely_active";

export interface Profile {
  id: string;
  full_name: string | null;
  age: number | null;
  height_cm: number | null;
  weight_kg: number | null;
  target_weight_kg: number | null;
  biological_sex: "male" | "female" | "other" | "prefer_not_to_say" | null;
  avatar_url: string | null;
  unit_weight: "kg" | "lb";
  unit_distance: "km" | "mi";
  unit_temperature: "C" | "F";
  language: string;
}

export interface AICoachProfile {
  id: string;
  user_id: string;
  primary_goal: FitnessGoalType | null;
  activity_level: ActivityLevel | null;
  avg_sleep_hours: number | null;
  preferred_wake_time: string | null;
  preferred_bed_time: string | null;
  workout_days_per_week: number | null;
  workout_duration_minutes: number | null;
  preferred_workout_types: string[];
  available_equipment: string[];
  diet_type: "vegetarian" | "non_vegetarian" | "vegan" | "eggetarian" | "other" | null;
  food_allergies: string[];
  food_intolerances: string[];
  disliked_foods: string[];
  meals_per_day: number | null;
  typical_meal_timing: string | null;
  work_schedule: string | null;
  sitting_hours: number | null;
  preferred_workout_time: string | null;
  water_habit: string | null;
  medical_conditions: string[];
  current_medications: string[];
  exercise_restrictions: string | null;
  injuries: string | null;
  pregnancy_status: string | null;
  setup_completed: boolean;
}

export interface HeartRateSummary {
  current: number | null;
  resting: number | null;
  average: number | null;
  min: number | null;
  max: number | null;
  is_demo: boolean;
  trend: { time: string; bpm: number }[];
}

export interface SleepSummary {
  total_minutes: number | null;
  deep_minutes: number | null;
  rem_minutes: number | null;
  light_minutes: number | null;
  awake_minutes: number | null;
  sleep_start: string | null;
  sleep_end: string | null;
  goal_hours: number;
  is_demo: boolean;
}

export interface ActivitySummary {
  steps: number;
  step_goal: number;
  distance_km: number;
  calories_burned: number;
  active_minutes: number;
  floors_climbed: number | null;
  is_demo: boolean;
}

export interface Spo2Summary {
  current: number | null;
  trend: { time: string; value: number }[];
  is_demo: boolean;
}

export interface TemperatureSummary {
  current_c: number | null;
  source: "skin" | "wrist" | "core_estimate" | null;
  is_demo: boolean;
}

export interface WeightSummary {
  current_kg: number | null;
  previous_kg: number | null;
  goal_kg: number | null;
  weekly_change_kg: number | null;
  monthly_change_kg: number | null;
  is_demo: boolean;
}

export interface HomeDashboardData {
  device: ConnectedDevice | null;
  heartRate: HeartRateSummary;
  sleep: SleepSummary;
  activity: ActivitySummary;
  spo2: Spo2Summary;
  temperature: TemperatureSummary;
  weight: WeightSummary;
}
