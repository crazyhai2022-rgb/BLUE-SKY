import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Blue Sky Fitness — Your Health. Your Data. Your AI Coach.",
  description:
    "Blue Sky Fitness is an AI-powered health and fitness platform. Connect your device. Understand your body. Let AI help you build a healthier routine.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#0b1e3f",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="bsf-app-bg min-h-full flex flex-col">{children}</body>
    </html>
  );
}
