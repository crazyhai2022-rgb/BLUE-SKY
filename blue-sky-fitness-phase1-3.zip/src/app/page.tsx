import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Activity, Bluetooth, HeartPulse, Sparkles } from "lucide-react";

export default async function LandingPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) redirect("/home");

  return (
    <div className="min-h-dvh flex flex-col">
      <header className="flex items-center justify-between px-5 py-5 max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bsf-gradient-primary flex items-center justify-center text-white font-bold text-sm">
            BS
          </div>
          <span className="font-bold">Blue Sky Fitness</span>
        </div>
        <Link href="/login" className="text-sm font-semibold text-bsf-blue">
          Log In
        </Link>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center text-center px-6 py-10 max-w-2xl mx-auto">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-sky-100 dark:bg-white/10 text-bsf-blue px-3 py-1 text-xs font-semibold mb-5">
          <Sparkles size={14} /> AI-Powered Health &amp; Fitness Platform
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
          BLUE SKY FITNESS
        </h1>
        <p className="mt-4 text-lg font-medium text-bsf-blue">
          Your Health. Your Data. Your AI Coach.
        </p>
        <p className="mt-4 text-slate-500 max-w-md">
          Connect your device. Understand your body. Let AI help you build a healthier routine.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          <Link href="/signup" className="w-full sm:w-auto">
            <Button size="lg" className="w-full">
              Get Started Free
            </Button>
          </Link>
          <Link href="/login" className="w-full sm:w-auto">
            <Button size="lg" variant="secondary" className="w-full">
              I already have an account
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-12 w-full">
          <Card className="text-left">
            <HeartPulse className="text-bsf-blue mb-2" size={22} />
            <p className="font-semibold text-sm">Track Real Health Data</p>
            <p className="text-xs text-slate-500 mt-1">
              Heart rate, sleep, SpO₂, steps and more from supported devices.
            </p>
          </Card>
          <Card className="text-left">
            <Bluetooth className="text-bsf-blue mb-2" size={22} />
            <p className="font-semibold text-sm">Honest Device Support</p>
            <p className="text-xs text-slate-500 mt-1">
              We clearly label Supported, Partially Supported, and Coming Soon.
            </p>
          </Card>
          <Card className="text-left">
            <Activity className="text-bsf-blue mb-2" size={22} />
            <p className="font-semibold text-sm">Personalized AI Coach</p>
            <p className="text-xs text-slate-500 mt-1">
              Safe, non-diagnostic guidance for workouts, nutrition and recovery.
            </p>
          </Card>
        </div>
      </main>

      <footer className="text-center text-xs text-slate-400 py-6">
        Blue Sky Fitness is a wellness &amp; fitness assistant, not a medical device.
      </footer>
    </div>
  );
}
