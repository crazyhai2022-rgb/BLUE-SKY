"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export default function SignupPage() {
  const router = useRouter();
  const supabase = createClient();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);

    if (password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }

    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name } },
    });
    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    if (data.session) {
      router.push("/ai-coach");
      router.refresh();
    } else {
      setInfo("Check your email to confirm your account, then log in.");
    }
  }

  return (
    <Card>
      <h1 className="text-xl font-bold text-center">Create Your Account</h1>
      <p className="text-sm text-slate-500 text-center mt-1">
        Start your health &amp; fitness journey
      </p>

      <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-3">
        <div>
          <label className="text-xs font-semibold text-slate-500">Full Name</label>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 w-full rounded-xl border border-bsf-border bg-transparent px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-bsf-sky"
            placeholder="Vicky Raj"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500">Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-xl border border-bsf-border bg-transparent px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-bsf-sky"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500">Password</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-xl border border-bsf-border bg-transparent px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-bsf-sky"
            placeholder="At least 8 characters"
          />
        </div>

        {error && <p className="text-xs text-red-500">{error}</p>}
        {info && <p className="text-xs text-emerald-600">{info}</p>}

        <Button type="submit" disabled={loading} className="mt-2">
          {loading ? "Creating account..." : "Sign Up"}
        </Button>
      </form>

      <p className="text-center text-sm text-slate-500 mt-5">
        Already have an account?{" "}
        <Link href="/login" className="text-bsf-blue font-semibold">
          Log in
        </Link>
      </p>
    </Card>
  );
}
