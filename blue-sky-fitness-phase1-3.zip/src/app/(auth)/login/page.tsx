"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.push("/home");
    router.refresh();
  }

  return (
    <Card>
      <h1 className="text-xl font-bold text-center">Welcome Back</h1>
      <p className="text-sm text-slate-500 text-center mt-1">Log in to your AI Coach</p>

      <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-3">
        <div>
          <label className="text-xs font-semibold text-slate-500">Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-xl border border-bsf-border bg-transparent px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-bsf-sky"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500">Password</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-xl border border-bsf-border bg-transparent px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-bsf-sky"
            placeholder="••••••••"
          />
        </div>

        {error && <p className="text-xs text-red-500">{error}</p>}

        <Button type="submit" disabled={loading} className="mt-2">
          {loading ? "Logging in..." : "Log In"}
        </Button>
      </form>

      <p className="text-center text-sm text-slate-500 mt-5">
        New to Blue Sky Fitness?{" "}
        <Link href="/signup" className="text-bsf-blue font-semibold">
          Create an account
        </Link>
      </p>
    </Card>
  );
}
