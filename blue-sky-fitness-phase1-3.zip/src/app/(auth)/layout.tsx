import type { ReactNode } from "react";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-dvh flex items-center justify-center px-5 py-10 bsf-app-bg">
      <div className="w-full max-w-sm">
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-10 h-10 rounded-xl bsf-gradient-primary flex items-center justify-center text-white font-bold">
            BS
          </div>
          <span className="font-bold text-lg">Blue Sky Fitness</span>
        </div>
        {children}
      </div>
    </div>
  );
}
