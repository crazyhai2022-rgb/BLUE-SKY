import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ProfileView } from "@/components/profile/ProfileView";

export default async function ProfilePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const [{ data: profile }, { data: goal }, { data: coach }, { data: devices }] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
    supabase.from("fitness_goals").select("*").eq("user_id", user.id).eq("status", "active").maybeSingle(),
    supabase.from("ai_coach_profiles").select("setup_completed, primary_goal").eq("user_id", user.id).maybeSingle(),
    supabase.from("connected_devices").select("id, device_name, status").eq("user_id", user.id),
  ]);

  return (
    <ProfileView
      email={user.email ?? ""}
      profile={profile}
      goal={goal}
      coachSetupComplete={coach?.setup_completed ?? false}
      devices={devices ?? []}
    />
  );
}
