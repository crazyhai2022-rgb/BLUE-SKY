import { Sparkles } from "lucide-react";
import { ComingSoonPage } from "@/components/ui/ComingSoonPage";

export default function AICoachPage() {
  return (
    <ComingSoonPage
      icon={<Sparkles size={22} />}
      title="AI Coach"
      tagline="Your personalized health &amp; fitness assistant"
      description="The full multi-step AI Coach setup (goals, activity level, sleep, workout preferences, nutrition, lifestyle, and safety information), daily plans, workout system, weekly schedule, and chat are being built next, on top of the Home dashboard and Supabase schema that already exist."
      bullets={[
        "9-step AI Coach setup wizard",
        "Daily plan: activity, workout, nutrition, hydration, sleep, recovery",
        "Ask Your AI Coach — chat grounded only in your real data",
        "Weekly schedule, workout tracking, and progress rings",
        "Non-diagnostic health trend analysis (7D / 30D / 90D)",
      ]}
    />
  );
}
