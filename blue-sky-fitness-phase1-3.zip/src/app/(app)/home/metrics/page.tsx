import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { DemoBadge } from "@/components/ui/Badge";
import { getDemoDashboard } from "@/lib/demo-data";

const EXTRA_METRICS = [
  { label: "Active Calories", value: "612 kcal" },
  { label: "Total Energy Expenditure", value: "1,840 kcal" },
  { label: "Distance Walked", value: "4.9 km" },
  { label: "Walking Pace", value: "6.4 min/km" },
  { label: "Active Minutes", value: "46 min" },
  { label: "Sedentary Time", value: "8h 20m" },
  { label: "Standing Time", value: "3h 10m" },
  { label: "Floors Climbed", value: "6 floors" },
  { label: "Water Intake", value: "1.6 L / 2.5 L" },
  { label: "Rest Days This Week", value: "1 day" },
  { label: "Weekly Goal Completion", value: "72%" },
  { label: "Fitness Consistency", value: "5/7 days active" },
];

export default function MoreMetricsPage() {
  const demo = getDemoDashboard();

  return (
    <div className="flex flex-col gap-4 pt-1">
      <div className="flex items-center gap-2">
        <Link href="/home" className="text-slate-500">
          <ArrowLeft size={18} />
        </Link>
        <h1 className="text-lg font-extrabold">All Metrics</h1>
        {demo && <DemoBadge className="ml-auto" />}
      </div>

      <div className="grid grid-cols-2 gap-3">
        {EXTRA_METRICS.map((m) => (
          <Card key={m.label}>
            <p className="text-[11px] text-slate-500">{m.label}</p>
            <p className="text-lg font-bold mt-1">{m.value}</p>
          </Card>
        ))}
      </div>

      <p className="text-xs text-slate-400 text-center">
        Values shown reflect Demo Mode. Real metrics populate here once a device syncs data for the relevant metric.
      </p>
    </div>
  );
}
