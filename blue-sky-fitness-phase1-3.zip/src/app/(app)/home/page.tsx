import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { HomeDashboard } from "@/components/home/HomeDashboard";

export default async function HomePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const [{ data: profile }, { data: goal }, { data: devices }] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
    supabase
      .from("fitness_goals")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle(),
    supabase
      .from("connected_devices")
      .select("*")
      .eq("user_id", user.id)
      .order("is_primary", { ascending: false }),
  ]);

  return (
    <HomeDashboard
      userName={profile?.full_name || user.email?.split("@")[0] || "there"}
      stepGoal={goal?.step_goal ?? 10000}
      sleepGoalHours={goal?.sleep_goal_hours ?? 8}
      realDevices={devices ?? []}
    />
  );
}
