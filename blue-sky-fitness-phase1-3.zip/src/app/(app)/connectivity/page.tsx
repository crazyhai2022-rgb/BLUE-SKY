import { Bluetooth } from "lucide-react";
import { ComingSoonPage } from "@/components/ui/ComingSoonPage";

export default function ConnectivityPage() {
  return (
    <ComingSoonPage
      icon={<Bluetooth size={22} />}
      title="Connectivity"
      tagline="Connect real wearables via Web Bluetooth"
      description="This page will let you connect real BLE devices using the Web Bluetooth API, with an honest capability map (Supported / Partially Supported / Not Supported) per device — no fabricated data, ever. For now, use Demo Mode on the Home page to preview the full experience."
      bullets={[
        "+ Connect Device → Bluetooth / Wi-Fi-Cloud / Health Platform / Manufacturer",
        "Web Bluetooth device picker with explicit user consent (no silent scanning)",
        "Device capability map: ✓ supported vs ✗ unsupported per metric",
        "Multi-device management: primary device, rename, disconnect, reconnect",
        "Supported Devices compatibility page + Coming Soon: Health Connect, Apple Health, NFC, GPS",
      ]}
    />
  );
}
