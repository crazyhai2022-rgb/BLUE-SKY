"use client";

import { Bell, Moon, Footprints, Bluetooth, Stethoscope } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

type Notification = {
  id: string;
  icon: React.ReactNode;
  title: string;
  message: string;
  time: string;
  suggestDoctor?: boolean;
};

// Demo notifications — illustrates the alert types Blue Sky Fitness sends
// (sleep, activity, device, and non-diagnostic health-pattern nudges).
// Real alerts are generated server-side from health_alerts once a device is
// connected and notification_settings are honoured.
const DEMO_NOTIFICATIONS: Notification[] = [
  {
    id: "1",
    icon: <Moon size={16} />,
    title: "Sleep below target",
    message:
      "Aaj raat aapki sleep 7h 32m thi, jo aapke 8h goal se kam hai. Agar ye pattern kai din chale ya aap thaka hua feel karein, doctor se sawal lena helpful ho sakta hai.",
    time: "7:05 AM",
    suggestDoctor: true,
  },
  {
    id: "2",
    icon: <Footprints size={16} />,
    title: "68% of step goal complete",
    message: "You have completed 68% of today's step goal. A short evening walk can help you close the gap.",
    time: "5:30 PM",
  },
  {
    id: "3",
    icon: <Bluetooth size={16} />,
    title: "Weekly workout plan is ready",
    message: "Your AI Coach generated this week's workout plan based on your recent activity.",
    time: "Yesterday",
  },
];

export default function NotificationsPage() {
  return (
    <div className="flex flex-col gap-4">
      <header className="flex items-center gap-2 pt-1">
        <Bell size={20} className="text-bsf-blue" />
        <h1 className="text-xl font-extrabold">Notifications</h1>
      </header>

      <Card className="bg-sky-50 dark:bg-white/5">
        <p className="text-xs text-slate-500 leading-relaxed">
          Blue Sky Fitness sends non-diagnostic wellness nudges — like low sleep or an unusual heart-rate pattern —
          and, when relevant, suggests speaking with a healthcare professional. It never diagnoses a condition.
          Manage which alerts you receive from <span className="font-semibold">Profile → Notification Settings</span>.
        </p>
      </Card>

      <div className="flex flex-col gap-3">
        {DEMO_NOTIFICATIONS.map((n) => (
          <Card key={n.id} className="flex gap-3">
            <div className="w-9 h-9 rounded-xl bg-bsf-surface-muted flex items-center justify-center text-bsf-blue shrink-0">
              {n.icon}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-semibold">{n.title}</p>
                <span className="text-[11px] text-slate-400 shrink-0">{n.time}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">{n.message}</p>
              {n.suggestDoctor && (
                <Badge tone="warning" className="mt-2">
                  <Stethoscope size={12} /> Consider a doctor consult
                </Badge>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
