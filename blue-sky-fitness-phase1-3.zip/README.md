# Blue Sky Fitness

**Your Health. Your Data. Your AI Coach.**

Blue Sky Fitness is an AI-powered health and fitness platform: connect a wearable, sync the metrics it actually exposes, and get personalized, non-diagnostic coaching, workouts, and schedules — built API-first so a native Android app can reuse the same backend later.

## Status

This repo is being built in phases (see `Development Order` below). **Completed so far:**

- Phase 1 — Responsive, mobile-first UI shell (bottom nav / sidebar), design system, landing page
- Phase 2 — Supabase Auth (signup/login/logout), session middleware (`proxy.ts`), full DB schema + Row Level Security
- Phase 3 — Home dashboard: device status, 6 health cards (steps, sleep, heart rate, SpO₂, temperature, weight), AI daily summary, Demo Mode

**Not yet built** (next phases): AI Coach setup wizard + chat, real Web Bluetooth device connectivity, workout/schedule system, progress analytics, PDF reports, notifications backend.

## Tech Stack

- **Frontend:** Next.js 16 (App Router, Turbopack), React 19, TypeScript, Tailwind CSS v4
- **Backend/DB:** Supabase (PostgreSQL + Auth + Row Level Security), Next.js Route Handlers for AI endpoints
- **Charts:** Recharts
- **AI:** Anthropic Claude API (server-only, never called from the browser)
- **Device connectivity (planned):** Web Bluetooth API / BLE GATT

## Getting Started

```bash
npm install
cp .env.example .env.local   # fill in your Supabase + Anthropic keys
npm run dev
```

Open http://localhost:3000.

## Environment Variables

See `.env.example`. Never commit `.env.local`.

- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` — safe for the browser; every table has Row Level Security so the anon key alone cannot leak another user's data.
- `SUPABASE_SERVICE_ROLE_KEY` — server-only, for future backend jobs. Never import this into any file that ships to the client.
- `ANTHROPIC_API_KEY` — server-only, used by future `/api/ai/*` route handlers.

## Database

The full schema (profiles, ai_coach_profiles, fitness_goals, connected_devices, device_capabilities, health_metrics, heart_rate_records, sleep_records, activity_records, spo2_records, temperature_records, weight_records, workouts, workout_sessions, nutrition_logs, water_logs, weekly_schedules, daily_tasks, ai_recommendations, ai_conversations, health_alerts, notification_settings, progress_reports) is already applied to the linked Supabase project with RLS on every table (`user_id = auth.uid()` ownership policies) and a trigger that provisions a profile + default goal + notification settings row on signup.

## Demo Mode

Because not every reviewer has a physical wearable, the Home dashboard ships a **Demo Mode** toggle (client-side only, per-browser). Demo data is clearly labeled with a purple "DEMO DATA" badge everywhere it appears and is never written into the real health tables.

## Device Compatibility Philosophy

Blue Sky Fitness does not claim every Bluetooth device exposes every metric. The Connectivity page (in progress) will show, per connected device, an honest **Supported / Partially Supported / Not Supported** map per metric, built on the Web Bluetooth API with explicit user consent — no silent scanning, no fabricated readings.

## Health & Safety Rules (enforced in copy and AI prompts)

1. Never fabricate health data.
2. Never claim a Bluetooth device is automatically fully compatible.
3. Never diagnose a disease or prescribe medication — only suggest consulting a healthcare professional when a pattern looks unusual.
4. Real data and Demo data are never mixed.

## Security Notes

- Row Level Security is enabled on every user-data table; verified with Supabase's security advisor.
- The `handle_new_user` signup trigger runs as `SECURITY DEFINER` but has `EXECUTE` revoked from `anon`/`authenticated` so it cannot be called directly over the API.
- No service-role or AI API key is ever imported into client-bundled code.

## Future: Native Android App

The database, Auth, and all `/api/*` route handlers are designed to be reused as-is by a future Android app (Kotlin + Jetpack, or React Native) for deeper background Bluetooth and Health Connect integration.

## Development Order

1. UI/UX + responsive app ✅
2. Auth + Supabase ✅
3. Home dashboard ✅
4. AI Coach setup wizard
5. AI Coach backend (`/api/ai/*`)
6. Connectivity architecture + device adapter layer
7. Web Bluetooth support
8. Health data normalization
9. Workout + weekly schedule
10. Progress analytics
11. PDF reports
12. Demo mode polish
13. Security testing
14. Production optimization
15. GitHub documentation
